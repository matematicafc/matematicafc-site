// Esta entrada não altera configurações ou bancos gravados no disco.
import { montarSimulado } from '../interface/estudante.mjs';
import { criarMecanismo } from '../mecanismo/index.mjs';
const estado = document.querySelector('#estado-local');
try {
  if (location.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(location.hostname)) {
    throw new Error('Use exclusivamente o servidor local de validação.');
  }
  const resposta = await fetch('./autorizacao.json', { cache: 'no-store' });
  if (!resposta.ok) throw new Error('Servidor local de validação não identificado.');
  const permissao = await resposta.json();
  if (permissao.ambiente !== 'MFC6-B2-VALIDACAO-LOCAL' || permissao.local !== true) throw new Error('Validação local não autorizada.');
  await montarSimulado(document.querySelector('#mfc-simulado'), {
    fabricaMecanismo(blocos) {
      if (blocos.length !== 4 || blocos.some(b => b.revisao_pedagogica !== 'aprovada' || b.questoes.length !== 25 || b.questoes.some(q => q.revisao_pedagogica.status !== 'aprovada'))) {
        throw new Error('Os quatro bancos precisam estar aprovados.');
      }
      const copias = structuredClone(blocos);
      for (const b of copias) for (const q of b.questoes) q.sorteio.ativo = true;
      return criarMecanismo(copias);
    },
  });
  estado.textContent = '';
} catch (erro) { estado.textContent = `Acesso de teste bloqueado. ${erro.message}`; }
