"""Servidor de inspeção: somente loopback; sem gravação, listagem ou serviços externos."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit, unquote
import argparse, json

BASE = Path(__file__).resolve().parents[1]
PREFIXO = '/6-ano/bloco-2/'
manifesto = json.loads((BASE / 'manifesto-execucao.json').read_text(encoding='utf-8'))
PERMITIDOS = {a['caminho'] for a in manifesto['arquivos']}
PERMITIDOS.update('validacao-local/' + n for n in ('index.html', 'iniciar.mjs', 'local.css'))

class Inspecao(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE), **kwargs)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        super().end_headers()

    def do_GET(self):
        if self.headers.get('Host', '') not in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'):
            self.send_error(403, 'Host local exigido'); return
        caminho = unquote(urlsplit(self.path).path)
        if caminho == '/':
            self.send_response(302); self.send_header('Location', PREFIXO + 'validacao-local/'); self.end_headers(); return
        if not caminho.startswith(PREFIXO):
            self.send_error(404); return
        relativo = caminho[len(PREFIXO):]
        if relativo == 'validacao-local/autorizacao.json':
            dados = json.dumps({'ambiente': 'MFC6-B2-VALIDACAO-LOCAL', 'local': True}).encode()
            self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(dados))); self.end_headers(); self.wfile.write(dados); return
        if relativo.endswith('/'): relativo += 'index.html'
        if relativo not in PERMITIDOS or (BASE / relativo).is_symlink():
            self.send_error(404); return
        self.path = '/' + relativo
        super().do_GET()

    def do_HEAD(self):
        self.send_error(405)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--porta', type=int, default=8000)
    args = parser.parse_args()
    servidor = ThreadingHTTPServer(('127.0.0.1', args.porta), Inspecao)
    print(f'Abra http://127.0.0.1:{servidor.server_port}{PREFIXO}validacao-local/', flush=True)
    try: servidor.serve_forever()
    except KeyboardInterrupt: pass
    finally: servidor.server_close()
