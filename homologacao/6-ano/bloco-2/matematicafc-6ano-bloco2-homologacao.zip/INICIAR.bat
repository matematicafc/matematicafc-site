@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys; sys.exit(sys.version_info.major != 3)" >nul 2>nul
if not errorlevel 1 goto com_py
python -c "import sys; sys.exit(sys.version_info.major != 3)" >nul 2>nul
if not errorlevel 1 goto com_python
echo Python 3 nao encontrado.
echo Instale Python 3 pelo site oficial https://www.python.org/downloads/windows/
echo Depois abra novamente este INICIAR.bat.
pause
exit /b 1
:com_py
py -3 "%~dp0iniciar.py"
if errorlevel 1 goto erro
exit /b 0
:com_python
python "%~dp0iniciar.py"
if errorlevel 1 goto erro
exit /b 0
:erro
echo Nao foi possivel iniciar. Leia a mensagem acima.
pause
exit /b 1
