"""Homologação local: integridade, servidor em loopback e abertura do navegador."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import threading
import webbrowser

RAIZ = Path(__file__).resolve().parent

def verificar():
    manifesto = json.loads((RAIZ / 'manifesto-pacote.json').read_text(encoding='utf-8'))
    for item in manifesto['arquivos']:
        relativo = Path(item['caminho'])
        if relativo.is_absolute() or '..' in relativo.parts:
            raise RuntimeError('Caminho inválido no manifesto.')
        arquivo = RAIZ / relativo
        if arquivo.is_symlink() or not arquivo.is_file():
            raise RuntimeError(f'Arquivo necessário ausente: {relativo}')
        dados = arquivo.read_bytes()
        if len(dados) != item['bytes'] or hashlib.sha256(dados).hexdigest() != item['sha256']:
            raise RuntimeError(f'Integridade divergente: {relativo}')

def main():
    verificar()
    caminho = RAIZ / '6-ano/bloco-2/validacao-local/servidor.py'
    spec = importlib.util.spec_from_file_location('servidor_homologacao', caminho)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    # O sistema escolhe uma porta livre. Somente este computador pode conectar-se.
    servidor = modulo.ThreadingHTTPServer(('127.0.0.1', 0), modulo.Inspecao)
    endereco = f'http://127.0.0.1:{servidor.server_port}/6-ano/bloco-2/validacao-local/'
    print('MatemáticaFC - homologação local do 6º ano, Bloco 2', flush=True)
    print('Integridade dos arquivos conferida. Publicação continua bloqueada.', flush=True)
    print('Mantenha esta janela aberta. Para encerrar: Ctrl+C.', flush=True)
    print('Se o navegador não abrir, copie o endereço abaixo para ele:', flush=True)
    print(endereco, flush=True)
    threading.Timer(0.5, lambda: webbrowser.open(endereco)).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print('Servidor encerrado.')
    finally:
        servidor.server_close()

if __name__ == '__main__':
    try:
        main()
    except Exception as erro:
        print(f'Não foi possível iniciar: {erro}', file=sys.stderr)
        sys.exit(1)
