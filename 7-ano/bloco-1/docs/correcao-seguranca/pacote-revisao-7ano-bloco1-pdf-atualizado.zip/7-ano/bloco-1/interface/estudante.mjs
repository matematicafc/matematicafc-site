import { montarSimulado as montarBase } from '../../../compartilhado/simulados/v1/estudante.mjs';
import { carregarBanco, criarMecanismo } from '../mecanismo/index.mjs';
import { CONFIGURACAO } from '../configuracao.mjs';
export function montarSimulado(container, opcoes = {}) {
  return montarBase(container, { ...opcoes, baseBanco:new URL('../banco-inedito/',import.meta.url), carregarBanco, criarMecanismo, configuracao:CONFIGURACAO });
}
