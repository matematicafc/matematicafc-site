@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 iniciar-revisao.py
) else (
  python iniciar-revisao.py
)
if errorlevel 1 (
  echo E necessario ter Python 3 instalado e extrair o ZIP inteiro.
  pause
)
