"""Inicie na pasta extraída do pacote. Requer apenas Python 3."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse, threading, webbrowser

def main():
    parser = argparse.ArgumentParser(description='Revisão local do MatemáticaFC, sem publicação.')
    parser.add_argument('--sem-navegador', action='store_true', help='Somente mostrar o endereço.')
    parser.add_argument('--porta', type=int, default=8000)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    interface = '/7-ano/bloco-1/interface/'
    if not (root / interface.lstrip('/') / 'index.html').is_file():
        parser.error('Extraia o ZIP inteiro antes de iniciar. Esta pasta deve conter 7-ano e compartilhado.')
    handler = partial(SimpleHTTPRequestHandler, directory=str(root))
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.porta), handler)
    except OSError:
        if args.porta != 8000:
            raise
        server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    url = f'http://127.0.0.1:{server.server_port}{interface}'
    print('Revisao local do MatematicaFC. Nao e uma publicacao.', flush=True)
    print(f'Abra neste computador: {url}', flush=True)
    print('Mantenha esta janela aberta. Para encerrar, pressione Ctrl+C.', flush=True)
    if not args.sem_navegador:
        timer = threading.Timer(0.5, webbrowser.open, args=(url,))
        timer.daemon = True
        timer.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
