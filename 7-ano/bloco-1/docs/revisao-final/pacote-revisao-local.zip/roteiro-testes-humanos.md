# Conferência pedagógica final — 7º ano, Bloco 1

Versão local, sem publicação. Utiliza os cinco JSON conferidos em `../auditoria-geral/resultado-correcoes-visuais.json`. A revisão continua pendente; não alterar o banco durante os testes.

## Abrir a aplicação

No ambiente do projeto, o servidor de revisão usa a porta 8000, restrita a `127.0.0.1`. Para iniciá-lo novamente, na raiz do repositório:

```sh
cd /workspace/matematicafc-site
python3 -m http.server 8000 --bind 127.0.0.1
```

No navegador da mesma máquina, digitar `http://127.0.0.1:8000/7-ano/bloco-1/interface/`.

**Atenção ao ambiente na nuvem:** esse endereço não é público. Digitar o endereço no seu computador não acessa o servidor da nuvem. Não foi criado um endereço de prévia pública. Para testar no próprio computador, obtenha o pacote `pacote-revisao-local.zip` desta pasta, extraia-o e abra o terminal na pasta extraída que contém `7-ano` e `compartilhado`. Execute `python3 -m http.server 8000 --bind 127.0.0.1` (no Windows, `py -m http.server 8000 --bind 127.0.0.1`) e use o endereço acima. É necessário Python 3; não é necessário instalar Node ou dependências para usar o simulado no navegador. Não abrir o index por `file://`, pois o carregamento de módulos e JSON pode ser bloqueado.

O ZIP contém cópias byte a byte dos arquivos de execução atuais, com manifesto de integridade. Não contém o 6º ano, dependências de desenvolvimento, nomes ou resultados de estudantes. A extração não altera os arquivos de origem. Parar o servidor com Ctrl+C. O processo precisa ser iniciado novamente após reiniciar o ambiente.

## Preparação humana

- Usar apenas um nome fictício ou deixar o campo vazio.
- Conferir em computador e em celular: 320 px de largura no modo responsivo do navegador e, quando disponível, um aparelho real. Emulação não substitui o aparelho.
- Realizar pelo menos duas tentativas: uma parcial, outra com todas as questões respondidas. Não recarregar a página durante uma tentativa: as respostas são mantidas em memória, apenas durante essa aplicação.
- Registrar ID, número da posição, largura, navegador, problema observado e resultado esperado. Os IDs podem ser consultados no gabarito/PDF e no inventário do banco; não assumir que a posição 1 corresponde sempre à mesma questão.
- A tentativa apresenta só 30 das 100 questões. Para a aprovação integral do banco, complementar com o caderno mestre e a galeria dos 60 recursos; novas tentativas aleatórias não garantem cobertura completa.

## Roteiro objetivo

| Passo | Ação | Resultado esperado / observar |
|---|---|---|
| 1 | Abrir a tela inicial | MatemáticaFC com favicon oficial; 7º ano, Bloco 1; 30 questões; aviso de revisão pendente e instruções compreensíveis. Botão habilitado após o carregamento. |
| 2 | Deixar o nome vazio e iniciar | Início permitido, sem login, cadastro, e-mail ou telefone. Nenhuma mensagem de erro de identificação. |
| 3 | Examinar a primeira questão | Uma questão por vez, enunciado integral, quatro alternativas legíveis, nenhuma indicação de acerto/erro. Avaliar adequação ao 7º ano e clareza do contexto. |
| 4 | Percorrer as 30 questões sem responder | Exatamente 30 posições, sem repetição de IDs. Registrar os assuntos e conferir seis de cada um. Não interpretar a letra atual como letra fixa do banco: as alternativas são embaralhadas. |
| 5 | Conferir dificuldades e visuais | Pela identificação de cada item e pelo inventário de referência: oito básicas, 14 intermediárias, oito desafiadoras; pelo menos três visuais em cada conteúdo e 15 no total. Não é esperado que a interface exiba o nível de dificuldade ao estudante. Cotas detalhadas abaixo. |
| 6 | Marcar alternativas em três questões | Contador passa a três respondidas. Mapa distingue respondidas e posição atual, sem informar correção. |
| 7 | Ir à questão 30, voltar à primeira e trocar a resposta | Questões e alternativas mantêm a ordem original da tentativa; resposta anterior aparece marcada e pode ser alterada. |
| 8 | Limpar uma resposta | Marcação é removida, contador diminui e questão volta a ser identificada como não respondida. |
| 9 | Usar Anterior, Próxima e números | Botões funcionam; Anterior indisponível na primeira e Próxima na última. Questão atual identificável. |
| 10 | Examinar SVGs e tabelas em 320 px | Sem cortes, sobreposição, distorção ou rolagem horizontal da aplicação. Tabelas empilhadas com rótulos completos; sinais negativos, unidades e frações legíveis. Ampliar o zoom também. |
| 11 | Revisar os recursos corrigidos quando sorteados; complementar na galeria | DP-03: ciclos 4/6 proporcionais; OI-16: planos independentes com ordem interna; FR-20: reserva hachurada distinta de pintura pronta; NR-15: descrição sem conversão dos decimais para frações. Conferir também NI-15, OI-20, FR-14 e FR-18. |
| 12 | Solicitar finalização parcial e cancelar | Diálogo informa a quantidade exata de questões em branco; cancelar preserva tentativa e respostas. Gabarito continua oculto. |
| 13 | Solicitar novamente e confirmar | Respostas ficam encerradas; acertos + erros + não respondidas = 30. Brancos são separados dos erros e não contam como acertos. |
| 14 | Consultar resultado por assunto | Cinco conteúdos com seis questões cada; percentual geral = acertos ÷ 30 × 100, com arredondamento de apresentação. Soma dos acertos por conteúdo corresponde ao total. |
| 15 | Abrir o gabarito e as resoluções | Todas as 30 questões na ordem da tentativa; alternativa escolhida, correta ou indicação de não respondida; resolução correspondente, sem divergência após embaralhamento. Avaliar clareza pedagógica e distratores. |
| 16 | Escolher Consultar na tela | Consulta continua disponível sem obrigação de baixar ou imprimir. Conferir expansão/fechamento do gabarito. |
| 17 | Baixar PDF | Download local abre sem erro; boletim resumido seguido do gabarito integral. Conferir data, nome fictício/ausente, 30 posições, totais, cinco conteúdos, letras escolhidas/corretas e resoluções. Verificar acentos, sinais, quebras de página, recursos e leitura no celular. |
| 18 | Imprimir e cancelar a impressão | Prévia legível, margens e quebras adequadas; cancelar não apaga o resultado. Conferir também preto e branco. A impressão física precisa de avaliação humana. |
| 19 | Iniciar nova aplicação | Volta à etapa inicial, contador e respostas zerados. Novo sorteio pode compartilhar questões com a tentativa anterior, mas nunca repete um ID dentro da tentativa. Não exigir que todas as questões mudem. |
| 20 | Iniciar com nome fictício, completar 30 respostas e finalizar | Nome aparece nos resultados/boletim; zero questões em branco; repetir conferência das letras e correção. Nome e resultados não devem gerar requisições de envio. |

### Cotas de cada tentativa

| Conteúdo | Básicas | Intermediárias | Desafiadoras | Total | Visuais mínimos |
|---|---:|---:|---:|---:|---:|
| DP — Divisibilidade, primos, MMC e MDC | 1 | 3 | 2 | 6 | 3 |
| NI — Representação e ordenação de inteiros | 2 | 3 | 1 | 6 | 3 |
| OI — Operações com inteiros | 1 | 3 | 2 | 6 | 3 |
| FR — Frações | 2 | 3 | 1 | 6 | 3 |
| NR — Representações dos racionais | 2 | 2 | 2 | 6 | 3 |
| **Total** | **8** | **14** | **8** | **30** | **15** |

## Teclado e leitor de tela

Executar sem mouse e, depois, com NVDA + Firefox/Chrome ou VoiceOver + Safari. Registrar navegador, sistema e tecnologia assistiva.

| Ação | Resultado esperado |
|---|---|
| Tab/Shift+Tab na tela inicial | Nome opcional e Iniciar alcançáveis; ordem lógica; indicador de foco visível. |
| Enter/Espaço nos botões; setas nas alternativas | Ativação por teclado; grupo de quatro opções anunciado, opção marcada identificável; nenhuma armadilha de foco. Setas no grupo podem mudar a resposta, comportamento normal de radios. |
| Navegar entre questões | Título da nova questão recebe foco; leitor identifica número, enunciado e grupo de alternativas. |
| Percorrer o mapa | Nomes acessíveis indicam número e respondida/não respondida; posição atual identificada por `aria-current`, além do estilo visual. |
| Alterar/limpar resposta | Contador e confirmação anunciados por região de atualização; nenhuma informação de correção prematura. Avaliar anúncios repetidos ou ausentes. |
| Abrir e cancelar o diálogo | Título e aviso compreensíveis; foco permanece no diálogo enquanto aberto; Tab e Shift+Tab circulam nos controles; Escape/cancelar retorna ao fluxo sem perda. Observar onde o foco retorna. |
| Ler SVGs e tabelas | SVG anunciado como imagem com descrição fiel; tabela com legenda e associação entre cabeçalhos e valores. Conferir especialmente as tabelas empilhadas: os rótulos auxiliares são visuais e ocultos da árvore acessível; os cabeçalhos semânticos originais permanecem. |
| Consultar resultados/gabarito | Título recebe foco; botões anunciam estado expandido/recolhido; resoluções e resultados lidos na ordem correta. |
| Zoom e contraste | Testar 200% e 400%, alto contraste e visualização sem cores. Textos/controles não se sobrepõem; diferenças relevantes não dependem apenas de cor. Registrar limitações. |

A inspeção de papéis, nomes acessíveis, foco e teclado é automática e básica. Não substitui uso de leitor de tela real, nem certifica WCAG ou acessibilidade do PDF. Rótulos SVG próximos de 12,7 px em 320 px continuam merecendo avaliação de conforto de leitura.

## Testes automatizados

A partir de `7-ano/bloco-1`, com as dependências já instaladas neste ambiente:

```sh
npm run validar
npm run test:interface
npm test
```

- `validar`: 100 modelos matemáticos, metadados, recursos e cotas.
- `test:interface`: fluxo, navegação, foco/teclado, layout, correção, PDF e impressão.
- `npm test`: inclui seleção de 10.000 aplicações e regressão do 6º ano. Ativar capturas opcionais com `MFC_CAPTURAS` e `MFC_REGRESSAO_CAPTURAS` apontando para diretórios de saída; sem essas variáveis, os testes de capturas são explicitamente ignorados.

Não executar o gerador do banco durante esta conferência. A aprovação deve se referir aos hashes já auditados, preservando os dados existentes.

## Registro para aprovação

Para cada verificação, marcar **aprovado**, **ajustar** ou **não verificado** e registrar ID/posição quando aplicável. Separar problema matemático, clareza pedagógica, apresentação e acessibilidade. A aprovação final é humana; testes automáticos aprovados não alteram o estado pendente.
