# Pacote de inspeção final — Ângulos e Polígonos

Data: 17/10/2026. Material exclusivamente para avaliação, com banco inativo e aprovação final pendente. O usuário aprovou o ajuste da justificativa D de AP-12; nenhum outro conteúdo foi alterado.

## Conteúdo

- `ABRIR-CADERNO-ANGULOS-POLIGONOS.html`: caderno estático com todas as questões, SVGs incorporados, descrições acessíveis, alternativas, gabaritos, resoluções e justificativas; sem JavaScript, fontes remotas, requisições de rede ou dependência de servidor. Os resumos podem ser recolhidos/expandidos pelo próprio navegador.
- `docs/revisao-pedagogica/angulos-poligonos.md`: caderno revisado.
- `banco-inedito/angulos-poligonos.json`: banco inativo, 25 questões.
- `recursos-visuais/`: 21 SVGs individuais, idênticos aos incorporados ao JSON e ao HTML.
- `docs/reconstrucao-ap/`: relatórios da reconstrução e do ajuste AP-12, auditoria individual e evidências de testes anteriores.
- `docs/fontes/`: fonte original preservada para rastreabilidade; a justificativa D antiga nela não é a redação vigente.
- `LEIA-ME.txt`, `VERIFICACAO-OFFLINE.json` e `MANIFESTO-SHA256.json`.

## Conferência desta entrega

As questões estão completas e em ordem AP-01 a AP-25: 8 fáceis, 12 médias, 5 difíceis. São 100 alternativas, 25 gabaritos, 25 resoluções e 21 SVGs. Os campos pedagógicos renderizados foram comparados individualmente ao banco de origem. O JSON, o Markdown e os SVGs foram copiados sem alterações de bytes e tiveram os hashes conferidos após extração do ZIP. Nenhuma questão foi ativada para sorteio.

- AP-12: gabarito B, 70°; justificativa D: “Calcula 110° − 90° = 20°, comparando com um ângulo reto, em vez de calcular quanto falta para completar a meia volta de 180°.”
- AP-23: giro adicional 200°, gabarito B.
- AP-25: quadrado e losango não quadrado, ambos com lados de 2 cm, ângulos do losango 60°/120°, gabarito C.
- AP-09: direções 0° e 70°, abertura de 70°.
- AP-10: direções 180° e 140° na referência direita, abertura de 40°.
- AP-22: direções 20° e 130°, abertura de 110°.

## Teste offline realizado e limitação

O ZIP foi extraído em uma pasta nova. O conteúdo do HTML extraído foi renderizado no Chromium com rede e JavaScript desativados, nas larguras 320 e 1.280 px. Os controles nativos de expandir/recolher as resoluções funcionaram. Não houve requisições de rede, erros JavaScript, transbordamento horizontal ou texto SVG cortado. O controle de coluna de 320 px também funcionou sem JavaScript.

A tentativa de abrir a URL `file://` diretamente foi bloqueada pelo navegador administrado deste ambiente (`ERR_BLOCKED_BY_ADMINISTRATOR`). Essa política foi respeitada e não alterada. A alternativa de teste consistiu em carregar em memória o texto exato do HTML extraído para conferir a renderização offline; isso não comprova abertura por duplo clique no Windows. O teste em Edge/Chrome/Firefox no notebook permanece pendente.

O caderno é autocontido e não utiliza `fetch`, módulos JavaScript, fontes externas ou recursos que precisem de servidor. A mudança em relação ao caderno técnico anterior consiste somente no formato de entrega estático; não houve alteração de conteúdo pedagógico. Os relatórios históricos ainda mencionam o caderno antigo que exigia HTTP.

Os testes anteriores arquivados registram 16 verificações estruturais/matemáticas, quatro cenários de componentes e a revisão AP-12 com sete testes específicos e 16 de regressão. Nesta entrega foram executados novamente os checks de conteúdo/arquivo/pacote e de renderização estática offline; esses números históricos não são apresentados como novos testes reexecutados.

## Integridade e segurança

CRC do ZIP conferido; nenhuma entrada com caminho absoluto, travessia de diretórios ou symlink. O pacote contém apenas HTML, SVG, JSON, Markdown e relatórios textuais. Não há BAT, EXE, instalador, script de inicialização ou biblioteca executável. As referências `url(#...)` dos SVGs são internas às hachuras; não são carregamento remoto.

Não houve nova análise pelo Microsoft Defender. Ausência de scripts ou êxito funcional não permite declarar o arquivo livre de ameaças. Mantenha as proteções ativas e não libere manualmente arquivos bloqueados.

Os 89 arquivos recuperados e os bancos/cadernos originais de desenvolvimento permaneceram inalterados durante a preparação desta entrega. Não houve commit, push, merge, deploy, alteração no Blogger, ativação do banco ou início do Assunto 4.

## Entrega pela conversa

O ZIP foi criado na área independente. Esta sessão não disponibiliza ferramenta de upload de arquivos gerados como anexo da conversa; apenas receber/baixar anexos do usuário está disponível. Portanto, a criação e validação local do ZIP estão concluídas, mas sua entrega como anexo baixável não está concluída. Nenhum envio ao GitHub ou a terceiros foi realizado.
