# Ângulos e Polígonos — 6º ano, Bloco 3

Reconstrução pendente de aprovação. Banco desativado para sorteio.

Fonte preservada: `docs/fontes/angulos-poligonos-revisado-original.txt`; SHA-256 `dbe271c5bca9f9e411993db7bbd1d5cc8a0cc30790c9edb90b43d08315557d26`.

## AP-01 — Onde fica a articulação?

facil · Reconhecer vértice e lados de um ângulo. Identificar abertura e origem comum.

Uma luminária de mesa tem duas hastes que se encontram em uma articulação, permitindo ajustar sua abertura. No esquema, O marca a articulação, enquanto A e B indicam pontos nas direções das hastes. Para explicar onde o ângulo é formado, a ficha de montagem pede a identificação do vértice e dos lados do ângulo AÔB. Qual registro está correto?

Descrição acessível: Duas direções partem do ponto O: uma segue horizontalmente para a direita passando por A; a outra sobe para a direita passando por B. O está na articulação das hastes. O pequeno arco indica a abertura entre elas.

![AP-01](../../recursos-visuais/AP-01.svg)

A. Vértice O; lados nas direções de OA e OB.
B. Vértice A; lados nas direções de AO e AB.
C. Vértice B; lados nas direções de BO e BA.
D. Vértices A e B; lado formado apenas por AB.

**Gabarito: A.**

Resolução comentada: O ponto O é a origem comum das duas direções e, portanto, o vértice. Os lados do ângulo são as semirretas que partem de O e passam por A e por B. O segmento imaginado entre A e B não substitui esses dois lados.

- B: Troca a articulação por um ponto de uma das hastes.
- C: Escolhe a extremidade de uma haste em vez da origem comum.
- D: Um ângulo tem um vértice e dois lados, não dois vértices e um lado.

Justificativa da contextualização: A articulação dá sentido à origem comum dos lados e à identificação do vértice.

## AP-02 — Um canto reto mesmo inclinado

facil · Reconhecer ângulo reto em diferentes orientações. Comparar com referência de quarto de volta.

Na montagem de uma estante, uma pessoa vai usar um esquadro para conferir se duas peças formam um canto de um quarto de volta. Os quatro desenhos mostram encontros de peças em posições diferentes, e alguns foram girados na folha. Qual desenho apresenta um ângulo reto, adequado a essa conferência?

Descrição acessível: Quatro encontros de segmentos, identificados por A, B, C e D, com comprimentos de traço iguais. A está inclinado com um lado para cima e à direita e o outro para cima e à esquerda; B tem um lado para a direita e outro diagonal para cima; C tem um lado para a direita e outro para cima e à esquerda; em D, os segmentos seguem direções opostas sobre uma mesma reta. Não há medidas numéricas escritas.

![AP-02](../../recursos-visuais/AP-02.svg)

A. Desenho B.
B. Desenho C.
C. Desenho D.
D. Desenho A.

**Gabarito: D.**

Resolução comentada: O ângulo reto corresponde a um quarto de volta, ou 90°. Em A, as duas direções são perpendiculares e formam essa abertura, mesmo com o desenho inclinado. B tem abertura menor, C tem abertura maior e D representa um ângulo raso.

- A: A abertura de B é menor que um quarto de volta.
- B: A abertura de C é maior que um quarto de volta.
- C: D representa meia volta, não um quarto de volta.

Justificativa da contextualização: A conferência de encaixe exige reconhecer o ângulo pela abertura, sem depender da posição do desenho.

## AP-03 — Abertura da porta de uma maquete

facil · Comparar ângulos agudos e obtusos. Julgar abertura, não comprimento dos lados.

Para decidir como representar uma porta aberta em uma maquete, uma estudante fez dois esquemas vistos de cima. As linhas tracejadas indicam a posição fechada e as linhas contínuas, a posição aberta; os desenhos foram feitos com comprimentos diferentes. Considerando a abertura entre essas posições, qual comparação está correta?

Descrição acessível: A: posição fechada horizontal para a direita e posição aberta na diagonal para cima e à direita, com traços mais longos. B: posição fechada horizontal para a direita e aberta para cima e à esquerda, com traços mais curtos. Tracejados identificam as posições fechadas; arcos marcam as aberturas menores.

![AP-03](../../recursos-visuais/AP-03.svg)

A. A é agudo, B é obtuso e B tem a maior abertura.
B. A é obtuso, B é agudo e A tem a maior abertura.
C. Os dois são retos, pois representam portas.
D. A tem a maior abertura porque seu traço é mais comprido.

**Gabarito: A.**

Resolução comentada: Em A, a abertura é menor que 90°, portanto é aguda. Em B, é maior que 90° e menor que 180°, portanto é obtusa. B tem a maior abertura; desenhar um traço mais comprido não torna um ângulo maior.

- B: Inverte as aberturas em relação à referência de 90°.
- C: O objeto representado não determina que sua abertura seja de 90°.
- D: Compara o tamanho dos traços, não a abertura entre as direções.

Justificativa da contextualização: As duas posições da porta distinguem abertura angular e comprimento dos traços.

## AP-04 — Qual contorno serve para a placa?

facil · Distinguir polígono de desenho aberto ou curvo. Conferir fechamento e segmentos de reta.

Um ateliê vai produzir placas seguindo uma regra do projeto: cada contorno deve ser fechado e formado somente por segmentos de reta, sem cruzamentos. Quatro modelos foram desenhados para a escolha, mas nem todos respeitam essa regra. Qual deles representa um polígono e pode ser usado?

Descrição acessível: Quatro contornos: A é fechado com três segmentos de reta; B tem três segmentos ligados e uma abertura entre suas extremidades; C é uma circunferência; D é fechado com três trechos retos e um trecho curvo.

![AP-04](../../recursos-visuais/AP-04.svg)

A. Modelo D.
B. Modelo A.
C. Modelo B.
D. Modelo C.

**Gabarito: B.**

Resolução comentada: A é um contorno fechado formado por três segmentos de reta que não se cruzam. B não fecha a região; C tem contorno curvo; D mistura segmentos e curva. Somente A atende às condições de um polígono.

- A: D é fechado, mas inclui um trecho curvo.
- C: O contorno B está aberto.
- D: A circunferência é curva e não é formada por segmentos de reta.

Justificativa da contextualização: Os requisitos de fabricação orientam a verificação de fechamento e natureza dos lados.

## AP-05 — Conferir os cantos da etiqueta

facil · Relacionar lados e vértices em polígonos. Contar elementos sem depender de orientação.

Uma gráfica vai recortar etiquetas no formato do contorno mostrado e colocar uma pequena marca em cada vértice para orientar a dobra da embalagem. Antes de programar o corte, o operador precisa conferir quantos segmentos formam o contorno e quantos vértices receberão marcas. Qual registro corresponde à figura?

Descrição acessível: Contorno fechado com vértices A, B, C, D, E e F, nessa ordem. Os segmentos unem A a B, B a C, C a D, D a E, E a F e F a A, sem cruzamentos; a figura não está alinhada como um retângulo.

![AP-05](../../recursos-visuais/AP-05.svg)

A. 5 lados e 6 vértices.
B. 6 lados e 5 vértices.
C. 12 lados e 12 vértices.
D. 6 lados e 6 vértices.

**Gabarito: D.**

Resolução comentada: Percorrendo o contorno uma vez, encontramos seis segmentos e seis encontros consecutivos entre eles. Assim, a etiqueta tem seis lados e seis vértices: é um hexágono. A inclinação dos lados não altera a contagem.

- A: Deixa de contar um dos segmentos do contorno fechado.
- B: Omite um dos encontros entre lados.
- C: Conta os mesmos elementos duas vezes ao percorrer a figura.

Justificativa da contextualização: O corte e a marcação dos cantos justificam conferir lados e vértices da mesma figura.

## AP-06 — Duas barras iguais no suporte

facil · Reconhecer classificação por lados de triângulos. Interpretar medidas correspondentes.

Na montagem de uma ponte em miniatura, três barras serão unidas pelas extremidades para formar a peça triangular do desenho. A lista informa duas barras de 5 cm e uma de 8 cm, e a equipe quer guardar o molde na categoria correta antes da montagem. Considerando a classificação pelos lados, como esse triângulo deve ser identificado?

Descrição acessível: Triângulo com base horizontal de 8 cm e dois lados inclinados de 5 cm cada. Os três lados são desenhados em proporção às medidas, sem marca de ângulo reto.

![AP-06](../../recursos-visuais/AP-06.svg)

A. Essas barras não podem formar um triângulo.
B. Isósceles, pois tem dois lados de mesma medida.
C. Equilátero, pois tem três lados de mesma medida.
D. Escaleno, pois seus três lados têm medidas diferentes.

**Gabarito: B.**

Resolução comentada: As medidas são 5 cm, 5 cm e 8 cm. Há dois lados iguais e um diferente, portanto o triângulo é isósceles. O desenho respeita essas medidas e mostra uma peça fechada.

- A: Duas barras de 5 cm alcançam uma abertura maior que 8 cm, permitindo o fechamento.
- C: O lado de 8 cm é diferente dos dois lados de 5 cm.
- D: As duas barras de 5 cm têm a mesma medida.

Justificativa da contextualização: A composição do suporte relaciona a igualdade das barras à classificação do triângulo.

## AP-07 — Uma descrição ainda incompleta

facil · Interpretar descrição de quadrilátero. Usar propriedades e definições inclusivas.

Uma loja de molduras recebeu a descrição de uma placa quadrilateral com quatro ângulos retos, mas o cliente ainda não informou os comprimentos dos lados. Para registrar o pedido sem inventar uma informação, a atendente precisa escolher uma classificação que seja garantida por essa descrição. Qual anotação é correta?

A. É necessariamente um quadrado.
B. É necessariamente um losango.
C. Não pode ser um retângulo porque faltam as medidas dos lados.
D. É um retângulo, podendo também ser um quadrado.

**Gabarito: D.**

Resolução comentada: Um quadrilátero com quatro ângulos retos é um retângulo. Se também tiver os quatro lados iguais, será um quadrado, que é um caso particular de retângulo. Como as medidas não foram informadas, não podemos garantir que seja quadrado.

- A: Quatro ângulos retos não garantem quatro lados iguais.
- B: A descrição não garante que os quatro lados tenham a mesma medida.
- C: Os quatro ângulos retos já permitem reconhecer um retângulo.

Justificativa da contextualização: O registro do pedido exige separar uma propriedade garantida de outra que ainda não foi informada.

## AP-08 — Virar a câmera para o outro lado

facil · Relacionar giro e abertura. Interpretar quarto, meia volta e volta completa.

Uma câmera está presa a um tripé e aponta para a entrada de um salão. Para filmar o palco, que fica exatamente na direção oposta, ela será girada no próprio suporte, sem mudar o tripé de lugar. Qual giro leva a câmera da direção inicial para a direção oposta?

A. Meia volta, correspondente a 180°.
B. Um quarto de volta, correspondente a 90°.
C. Uma volta completa, correspondente a 360°.
D. Três quartos de volta, correspondentes a 270°.

**Gabarito: A.**

Resolução comentada: Para apontar na direção oposta, a câmera precisa fazer meia volta, ou 180°. Um quarto ou três quartos de volta apontariam para os lados; uma volta completa a faria voltar à direção inicial.

- B: Leva a câmera a uma direção lateral.
- C: Faz a câmera terminar na mesma direção inicial.
- D: Termina em uma direção lateral, não na oposta.

Justificativa da contextualização: A posição do palco dá sentido à relação entre meia volta e mudança de direção.

## AP-09 — A dobra do suporte de papel

media · Ler transferidor com lado no zero. Selecionar escala com origem correta.

Para dobrar um suporte de papel, uma estudante precisa registrar a abertura indicada no molde. Ela colocou o centro do transferidor no vértice e alinhou um dos lados com o zero à direita, como mostra o desenho. Usando a escala que começa nesse zero, qual medida deve registrar?

Descrição acessível: Transferidor semicircular com centro O, marcas de 10° e duas escalas em sentidos opostos. O lado inicial aponta para a direita. Na escala que começa com zero à direita, o segundo lado alcança a primeira marca depois de 60°, antes de 90°. A escala oposta começa com zero à esquerda.

![AP-09](../../recursos-visuais/AP-09.svg)

A. 60°.
B. 80°.
C. 70°.
D. 110°.

**Gabarito: C.**

Resolução comentada: A leitura começa no zero à direita, onde está o lado inicial. Nessa escala, o outro lado passa pela primeira marca de 10° depois de 60°. Portanto, a abertura é 70°.

- A: Lê a marca numerada anterior e ignora a divisão seguinte.
- B: Avança uma divisão de 10° além do lado inclinado.
- D: Usa a escala que começa no lado oposto.

Justificativa da contextualização: O alinhamento do molde ao instrumento determina a origem correta da leitura.

## AP-10 — Duas escalas, uma medida

media · Comparar escalas interna e externa do transferidor. Usar lado inicial e sentido da abertura.

Uma peça articulada foi medida com um transferidor de duas escalas. O lado inicial está alinhado à esquerda, mas um colega anotou 140° depois de ler a escala que começa à direita. Antes de usar essa anotação para ajustar a peça, qual leitura deve ser aceita?

Descrição acessível: Transferidor de dupla escala, com marcas de 10°. O lado inicial aponta horizontalmente para a esquerda. O segundo lado sobe para a esquerda e cruza os números 40 e 140 das escalas opostas. A escala que começa com zero à esquerda mostra 40 nesse cruzamento; a que começa à direita mostra 140.

![AP-10](../../recursos-visuais/AP-10.svg)

A. 180°, porque há duas escalas no instrumento.
B. 100°, subtraindo os dois números encontrados.
C. 40°, usando a escala cujo zero está à esquerda.
D. 140°, usando a escala cujo zero está à direita.

**Gabarito: C.**

Resolução comentada: O lado inicial coincide com o zero à esquerda. É nessa escala que devemos acompanhar a abertura até o segundo lado, que indica 40°. O número 140° pertence à escala que começa do outro lado e não mede o ângulo indicado.

- A: O alcance da escala não é a medida da abertura indicada.
- B: Subtrai leituras de escalas opostas sem relação com a abertura medida.
- D: Ignora o alinhamento do lado inicial à esquerda.

Justificativa da contextualização: A correção de uma anotação depende da posição inicial, não da escolha do número maior no instrumento.

## AP-11 — Completar a abertura do suporte

media · Encontrar abertura que completa ângulo reto. Decompor uma abertura conhecida.

Um suporte articulado precisa formar um ângulo reto para manter uma placa na posição prevista. Uma haste interna já ocupa 35° dessa abertura, e a parte restante será ajustada com uma segunda articulação, como mostra o esquema. Qual deve ser a medida dessa parte para que as duas juntas completem o ângulo reto?

Descrição acessível: Duas direções perpendiculares partem de O: horizontal para a direita e vertical para cima, com marca de ângulo reto. Uma direção interna divide a abertura. A parte junto à horizontal está marcada 35° e a parte junto à vertical, com interrogação.

![AP-11](../../recursos-visuais/AP-11.svg)

A. 125°.
B. 65°.
C. 55°.
D. 35°.

**Gabarito: C.**

Resolução comentada: O ângulo reto mede 90°. As duas partes devem somar 90°, e uma delas já mede 35°. A parte restante é 90° − 35° = 55°; conferindo, 35° + 55° = 90°.

- A: Soma 35° a 90° em vez de calcular o que falta.
- B: Trata 90° como se fosse 100° ao encontrar a parte restante.
- D: Repete a medida conhecida em vez de completar os 90°.

Justificativa da contextualização: A montagem exige completar uma abertura conhecida a partir de uma parte já determinada.

## AP-12 — A direção marcada na dobradura

media · Encontrar abertura em ângulo raso. Relacionar partes de uma abertura.

Uma folha foi aberta sobre a mesa, e sua borda reta foi usada como referência para marcar uma dobra. No ponto O, a direção da dobra divide a meia volta acima da borda em duas partes: uma mede 110° e a outra está indicada por um ponto de interrogação. Para registrar a orientação completa do molde, qual é a medida que falta?

Descrição acessível: Uma linha horizontal passa por O, com direções para a direita e para a esquerda. Uma semirreta parte de O para cima e à esquerda. A parte superior entre a direção direita e essa semirreta está marcada 110°; a parte superior restante até a direção esquerda tem interrogação.

![AP-12](../../recursos-visuais/AP-12.svg)

A. 290°.
B. 70°.
C. 110°.
D. 20°.

**Gabarito: B.**

Resolução comentada: As duas partes estão sobre uma linha reta e juntas formam meia volta, ou 180°. A parte que falta é 180° − 110° = 70°. A conferência é 110° + 70° = 180°.

- A: Soma a parte conhecida aos 180° em vez de completar a meia volta.
- C: Repete a parte conhecida.
- D: Calcula 110° − 90° = 20°, comparando com um ângulo reto, em vez de calcular quanto falta para completar a meia volta de 180°.

Justificativa da contextualização: A borda da folha define a referência de meia volta e diferencia o problema de completar 90°.

## AP-13 — Para onde o robô termina apontando?

media · Interpretar sequência de giros. Distinguir sentido, posição e abertura do giro.

Em um teste de programação, um robô começa apontando para o leste e permanece no mesmo lugar durante dois comandos de giro. Primeiro, faz um quarto de volta à direita; depois, faz meia volta à esquerda a partir da direção em que ficou. Para conferir a programação antes de fazê-lo andar, em qual direção ele estará apontando ao final?

Descrição acessível: Rosa de direções: norte acima, sul abaixo, leste à direita e oeste à esquerda. Uma seta inicial aponta para leste. Abaixo aparecem somente os comandos na ordem: primeiro, direita 90°; segundo, esquerda 180°. A direção final não está desenhada.

![AP-13](../../recursos-visuais/AP-13.svg)

A. Norte.
B. Sul.
C. Leste.
D. Oeste.

**Gabarito: A.**

Resolução comentada: Apontando para o leste, um quarto de volta à direita leva o robô para o sul. A partir do sul, meia volta à esquerda o leva para o norte. Os giros mudam a orientação, mas não deslocam o robô.

- B: Considera apenas o primeiro comando.
- C: Supõe que os dois comandos se anulam, embora tenham amplitudes diferentes.
- D: Confunde a meia volta final com uma direção lateral a partir do sul.

Justificativa da contextualização: A sequência de comandos exige acompanhar sentido e orientação sem confundir giro e deslocamento.

## AP-14 — Um molde realmente regular

media · Verificar regularidade de polígono. Conferir lados e ângulos, não só aparência.

Uma fabricante de peças decorativas precisa escolher um molde de polígono regular, com todos os lados e todos os ângulos internos iguais. Os quatro candidatos da figura têm medidas e marcações para permitir a conferência, sem depender apenas da aparência. Qual molde atende às duas condições de regularidade?

Descrição acessível: Quatro moldes na mesma escala. A: losango com quatro lados de 2 cm e ângulos de 60° e 120°. B: retângulo com lados consecutivos de 4 e 2 cm e quatro ângulos retos. C: quadrado com quatro lados de 2 cm e quatro ângulos retos. D: triângulo com lados de 2, 2 e 3 cm. Todos têm o mesmo preenchimento e traço.

![AP-14](../../recursos-visuais/AP-14.svg)

A. Molde B.
B. Molde C.
C. Molde D.
D. Molde A.

**Gabarito: B.**

Resolução comentada: A tem quatro lados iguais, mas seus ângulos não são todos iguais. B tem quatro ângulos retos, mas lados de 4 cm e 2 cm. C é um quadrado: quatro lados de 2 cm e quatro ângulos retos, atendendo às duas condições. D tem lados de 2, 2 e 3 cm e não é regular.

- A: O retângulo tem ângulos iguais, mas comprimentos de lado diferentes.
- C: O triângulo tem dois lados de 2 cm e um de 3 cm, portanto não tem todos os lados iguais.
- D: O losango tem lados iguais, mas apresenta ângulos de 60° e 120°.

Justificativa da contextualização: A exigência do molde obriga a verificar igualdade de lados e de ângulos simultaneamente.

## AP-15 — Duas informações na ficha da peça

media · Classificar triângulo por lados e ângulos. Aplicar duas classificações compatíveis.

Um painel será montado com peças triangulares, e cada ficha precisa indicar a classificação pelos lados e pelos ângulos. A peça mostrada tem lados de 3 cm, 4 cm e 5 cm; o pequeno quadrado no desenho identifica um ângulo reto. Qual ficha apresenta as duas classificações corretas?

Descrição acessível: Triângulo com lados de 3 cm, 4 cm e 5 cm em proporção correta. O canto entre os lados de 3 e 4 cm possui a marca quadrada de ângulo reto.

![AP-15](../../recursos-visuais/AP-15.svg)

A. Escaleno e obtusângulo.
B. Equilátero e acutângulo.
C. Escaleno e retângulo.
D. Isósceles e retângulo.

**Gabarito: C.**

Resolução comentada: As três medidas de lado são diferentes, portanto o triângulo é escaleno. A marca de ângulo reto mostra que ele também é retângulo. Essas classificações se referem a critérios diferentes e podem ser usadas juntas.

- A: Reconhece os lados diferentes, mas ignora a marca de ângulo reto.
- B: Os lados não são iguais e há um ângulo reto explicitamente marcado.
- D: Reconhece o ângulo reto, mas não há dois lados iguais.

Justificativa da contextualização: A ficha organiza duas propriedades independentes, sem exigir o cálculo de ângulos do triângulo.

## AP-16 — Uma peça pode receber duas etiquetas?

media · Relacionar classes de quadriláteros. Reconhecer quadrado como caso de retângulo e losango.

Um catálogo organiza suas peças por propriedades: a etiqueta “retângulo” identifica quadriláteros com quatro ângulos retos, e a etiqueta “losango” identifica quadriláteros com quatro lados iguais. Uma peça quadrada foi conferida e tem quatro lados de 3 cm e quatro ângulos retos, como mostra a figura. Para que a busca no catálogo encontre todas as peças adequadas, quais etiquetas ela deve receber?

Descrição acessível: Peça quadrada com lados de 3 cm e marca de ângulo reto em cada canto. Abaixo, duas definições separadas: retângulo, quatro ângulos retos; losango, quatro lados iguais. As etiquetas que a peça receberá não estão assinaladas.

![AP-16](../../recursos-visuais/AP-16.svg)

A. Nenhuma, porque ser quadrado impede pertencer às outras categorias.
B. Retângulo e losango.
C. Somente retângulo.
D. Somente losango.

**Gabarito: B.**

Resolução comentada: A peça satisfaz a definição de retângulo porque tem quatro ângulos retos. Também satisfaz a definição de losango porque tem quatro lados iguais. Ser quadrado não exclui essas propriedades: ela deve receber as duas etiquetas.

- A: Trata os nomes como categorias exclusivas, contrariando as definições apresentadas.
- C: Desconsidera que os quatro lados também são iguais.
- D: Desconsidera que os quatro ângulos também são retos.

Justificativa da contextualização: A organização do catálogo dá função à inclusão de uma mesma figura em mais de uma classe.

## AP-17 — O setor que falta no horizonte

media · Relacionar aberturas em torno de um ponto. Usar volta completa sem teorema de soma de polígono.

Em uma atividade de observação do céu, um grupo dividiu a volta completa do horizonte em quatro setores, sem espaços nem sobreposições. No mapa em torno do ponto O, três setores já foram registrados com 90°, 120° e 80°. Antes de distribuir as direções de observação entre as equipes, qual medida deve ser registrada no setor restante?

Descrição acessível: Quatro setores consecutivos em torno de O, sem lacunas nem sobreposições. Partindo da direção horizontal direita e seguindo no sentido anti-horário, aparecem os setores marcados 90°, 120°, 80° e interrogação. As quatro direções são desenhadas com a mesma extensão.

![AP-17](../../recursos-visuais/AP-17.svg)

A. 150°.
B. 80°.
C. 70°.
D. 290°.

**Gabarito: C.**

Resolução comentada: Uma volta completa mede 360°. Os setores conhecidos somam 90° + 120° + 80° = 290°. O setor restante mede 360° − 290° = 70°, completando o horizonte sem lacunas.

- A: Desconta 90° e 120° da volta completa, mas esquece o setor de 80°.
- B: Repete a medida de um setor conhecido em vez de calcular o restante.
- D: Informa a soma dos setores conhecidos, não o setor restante.

Justificativa da contextualização: A divisão do horizonte exige completar uma volta em torno do ponto de observação, sem recorrer à soma de ângulos de polígonos.

## AP-18 — A etiqueta da face da embalagem

media · Classificar polígono no contorno de uma face. Considerar lados e ângulos da face plana.

Uma embalagem será identificada por uma etiqueta que acompanha apenas o contorno de sua face frontal. O desenho mostra a embalagem em perspectiva, mas a face que receberá a etiqueta está destacada por hachuras; as outras linhas pertencem à profundidade da embalagem. Ao cadastrar o formato plano da etiqueta, qual identificação deve ser usada?

Descrição acessível: Embalagem em perspectiva com face frontal hachurada em forma de casa. Essa face tem uma base horizontal, duas laterais verticais e duas bordas inclinadas no topo. Traços para cima e à direita mostram a profundidade da embalagem e não fazem parte do contorno da face frontal.

![AP-18](../../recursos-visuais/AP-18.svg)

A. Pentágono, com 5 lados.
B. Hexágono, com 6 lados.
C. Quadrilátero, com 4 lados.
D. Triângulo, com 3 lados.

**Gabarito: A.**

Resolução comentada: O contorno da face hachurada tem uma base, dois lados verticais e dois segmentos inclinados no topo: cinco lados. A etiqueta tem forma de pentágono. As linhas de profundidade não são lados dessa face plana.

- B: Inclui uma linha da profundidade no contorno da face frontal.
- C: Ignora um dos dois segmentos inclinados do topo.
- D: Considera apenas a parte superior da face.

Justificativa da contextualização: O uso de uma etiqueta delimita qual face e quais segmentos devem ser classificados no desenho espacial.

## AP-19 — O que a medição dos lados garante?

media · Inferir classe a partir de propriedades dadas. Separar condições necessárias e suficientes.

Uma vidraçaria recebeu uma placa quadrilateral convexa cujos quatro lados medem 4 cm, mas os ângulos ainda não foram medidos. O cadastro precisa registrar uma classe garantida pelas medidas disponíveis, sem afirmar que os cantos são retos. Qual conclusão é segura?

A. É necessariamente um quadrado.
B. É necessariamente um retângulo.
C. Não é possível reconhecer nenhuma classe de quadrilátero.
D. É um losango, podendo ou não ser um quadrado.

**Gabarito: D.**

Resolução comentada: Um quadrilátero convexo com os quatro lados iguais é um losango. Ele também será quadrado se tiver quatro ângulos retos, mas isso ainda não foi verificado. Portanto, a informação disponível garante losango e permite, sem garantir, que seja quadrado.

- A: Lados iguais não garantem quatro ângulos retos.
- B: Não há informação que garanta ângulos retos.
- C: Os quatro lados iguais já garantem a classificação como losango.

Justificativa da contextualização: A ficha separa a informação suficiente para uma classe da informação ainda necessária para outra.

## AP-20 — Hastes maiores mudam a abertura?

media · Analisar afirmação sobre tamanho dos lados de um ângulo. Distinguir extensão do desenho e abertura.

Um instrumento articulado foi ajustado para uma abertura de 60° e teve a articulação travada. Depois, suas duas hastes foram prolongadas para facilitar o desenho, mantendo exatamente as mesmas direções. Um colega afirmou que dobrar o comprimento das hastes faria o ângulo dobrar. Qual avaliação descreve corretamente a abertura após a mudança?

A. Permanece 60°, pois as direções dos lados não mudaram.
B. Passa a 120°, pois as duas hastes ficaram mais compridas.
C. Passa a 30°, pois a mesma abertura foi repartida entre hastes maiores.
D. Passa a 180°, pois prolongar as hastes sempre forma uma linha reta.

**Gabarito: A.**

Resolução comentada: A medida do ângulo depende da abertura entre as direções, não do comprimento dos trechos desenhados. Como a articulação ficou travada e as direções foram mantidas, a abertura continua sendo 60°.

- B: Aplica ao ângulo a mudança do comprimento dos traços.
- C: Supõe uma divisão da abertura que não ocorreu.
- D: Prolongar lados em suas próprias direções não os torna opostos.

Justificativa da contextualização: A alteração de alcance do instrumento permite analisar uma afirmação equivocada sobre comprimento e abertura.

## AP-21 — O molde que atende a todas as condições

dificil · Escolher figura que atende a várias propriedades. Confrontar paralelismo, lados e ângulos indicados.

Uma composição artística precisa de um molde quadrilateral que tenha dois pares de lados opostos paralelos e os quatro lados de mesma medida. Para criar o efeito inclinado previsto no projeto, nenhum de seus ângulos pode ser reto. As medidas e marcações das quatro propostas estão na figura. Qual molde atende simultaneamente às três condições?

Descrição acessível: Quatro quadriláteros com o mesmo traço e preenchimento. A: quatro lados de 2 cm, dois pares de lados opostos paralelos, ângulos alternados de 60° e 120°. B: quadrado de lado 2 cm. C: retângulo de 4 cm por 2 cm. D: trapézio com bases paralelas de 4 e 2 cm e laterais de 2 cm; suas laterais não são paralelas.

![AP-21](../../recursos-visuais/AP-21.svg)

A. Molde C.
B. Molde D.
C. Molde A.
D. Molde B.

**Gabarito: C.**

Resolução comentada: A é um losango com quatro lados de 2 cm e ângulos de 60° e 120°; seus lados opostos são paralelos e não há ângulo reto. B é quadrado e C é retângulo, ambos com ângulos retos. D tem somente um par de lados paralelos. Apenas A satisfaz todas as exigências.

- A: O retângulo tem lados opostos paralelos, mas não tem os quatro lados iguais e tem ângulos retos.
- B: O trapézio tem apenas um par de lados opostos paralelos e nem todos os lados são iguais.
- D: O quadrado tem lados iguais e paralelismo, mas seus ângulos são retos.

Justificativa da contextualização: A decisão de projeto exige confrontar paralelismo, igualdade de lados e ausência de ângulos retos ao mesmo tempo.

## AP-22 — Quando nenhum lado coincide com o zero

dificil · Medir abertura quando lado inicial não está no zero. Comparar posições na mesma escala.

Na conferência de uma abertura, o centro do transferidor foi colocado corretamente no vértice, mas nenhum dos dois lados ficou alinhado ao zero. Na mesma escala, que cresce a partir da direita, um lado passa por 20° e o outro por 130°, como mostra a figura. A pessoa responsável não quer mover o instrumento e precisa descobrir a abertura menor entre esses lados. Qual medida deve registrar?

Descrição acessível: Transferidor com centro O e uma escala crescente a partir do zero à direita, com marcas de 10°. Os dois lados partem de O e cruzam as posições 20° e 130° da mesma escala; nenhum coincide com o zero.

![AP-22](../../recursos-visuais/AP-22.svg)

A. 130°.
B. 150°.
C. 70°.
D. 110°.

**Gabarito: D.**

Resolução comentada: As duas posições foram lidas na mesma escala, portanto a abertura entre elas é a diferença: 130° − 20° = 110°. O valor 130° só seria a medida do ângulo se o lado inicial estivesse no zero dessa escala.

- A: Usa a posição final como medida, ignorando o início em 20°.
- B: Soma as duas posições em vez de comparar a distância angular.
- C: Calcula a abertura suplementar em vez da indicada entre os dois lados.

Justificativa da contextualização: O alinhamento incompleto do instrumento exige medir pela diferença de posições, não copiar uma leitura isolada.

## AP-23 — Completar a rotação da câmera

dificil · Reconstruir giro que completa uma volta. Compor giros e interpretar sentido.

Em uma filmagem, uma câmera gira no tripé sem sair do lugar: primeiro 80° no sentido horário, depois 30° no sentido anti-horário e, por fim, 110° no sentido horário. O roteiro pede que, ao final, ela complete uma volta inteira no sentido horário e volte a apontar para a direção inicial. Nessa contagem, o giro anti-horário desfaz parte dos giros horários. Qual giro horário adicional deve ser programado?

Descrição acessível: Três comandos na ordem, cada um acompanhado por uma seta curva indicando o sentido: 1, horário 80°; 2, anti-horário 30°; 3, horário 110°. As setas ilustram os comandos separadamente e não mostram a orientação final nem o giro que falta.

![AP-23](../../recursos-visuais/AP-23.svg)

A. 50°.
B. 200°.
C. 140°.
D. 160°.

**Gabarito: B.**

Resolução comentada: Os giros no sentido horário somam 80° + 110° = 190°. Como o giro de 30° no sentido contrário desfaz parte deles, o avanço no sentido horário é de 190° − 30° = 160°. Uma volta inteira corresponde a 360°, então faltam 360° − 160° = 200° nesse sentido. Com esse giro adicional, a câmera completa a volta prevista e volta a apontar para a direção inicial.

- A: Informa apenas 80° menos 30°, ignorando o terceiro giro e a rotação que falta.
- C: Soma todos os giros como se fossem no mesmo sentido e calcula 360° menos 220°.
- D: Informa a rotação líquida já realizada, não a que falta.

Justificativa da contextualização: O retorno programado exige compor giros de sentidos diferentes e distinguir o que já foi feito do que falta.

## AP-24 — Duas afirmações no catálogo

dificil · Avaliar inclusão entre classes com exemplos. Usar propriedade indicada sem generalizar pela aparência.

Na revisão de um catálogo de peças, foram encontradas duas afirmações: I — “Todo quadrado é um retângulo”; II — “Todo retângulo é um quadrado”. As peças A, B e C da figura podem ser usadas para conferir essas frases pelas medidas dos lados e pelos ângulos. Qual decisão é correta e apresenta uma peça que demonstra o problema encontrado?

Descrição acessível: Três peças na mesma escala. A: retângulo com lados de 4 cm e 2 cm e quatro ângulos retos. B: quadrado com quatro lados de 3 cm e quatro ângulos retos. C: losango com quatro lados de 3 cm e ângulos alternados de 60° e 120°. Não há marca indicando qual afirmação do catálogo deve ser corrigida.

![AP-24](../../recursos-visuais/AP-24.svg)

A. Corrigir I e manter II: B é quadrado e também é retângulo.
B. Manter as duas: B é quadrado e retângulo.
C. Corrigir as duas: C é losango e não tem ângulos retos.
D. Manter I e corrigir II: A é retângulo e não é quadrado.

**Gabarito: D.**

Resolução comentada: I é verdadeira: o quadrado tem quatro ângulos retos, atendendo à definição de retângulo. II é falsa: A tem quatro ângulos retos e lados de 4 cm e 2 cm, portanto é retângulo sem ser quadrado. B pertence às duas classes, mas não garante que elas sejam iguais. C não contradiz I.

- A: B confirma, em vez de negar, que um quadrado também é retângulo.
- B: Um exemplo comum às classes não prova que todos os retângulos sejam quadrados.
- C: A existência de um losango não retângulo não invalida a inclusão dos quadrados nos retângulos.

Justificativa da contextualização: A conferência exige distinguir um exemplo que satisfaz duas classes de um contraexemplo a uma afirmação universal.

## AP-25 — Medir os lados é suficiente?

dificil · Justificar por que uma condição não garante regularidade. Exigir igualdade de lados e de ângulos.

Uma fabricante quer identificar como regulares apenas as peças que tenham todos os lados e todos os ângulos internos iguais. Um funcionário propôs conferir somente os lados e liberar qualquer quadrilátero com quatro lados iguais, sem medir os ângulos. Antes de adotar esse procedimento, a equipe compara as duas peças da figura, que passaram pela conferência dos lados, para avaliar se o teste pode aprovar uma peça inadequada. Qual análise está correta?

Descrição acessível: Duas peças na mesma escala e com o mesmo preenchimento. Peça A: quadrado com quatro lados de 2 cm e marca de ângulo reto nos quatro cantos. Peça B: losango não quadrado com quatro lados de 2 cm e ângulos alternados de 60° e 120°. Marcas transversais iguais identificam a igualdade dos lados nas duas peças. Não há destaque de alternativa correta nem rótulos de regularidade ou aprovação.

![AP-25](../../recursos-visuais/AP-25.svg)

A. É suficiente: qualquer quadrilátero com lados iguais e contorno fechado é regular.
B. Não é suficiente: nenhuma peça quadrilateral pode ter todos os lados e ângulos iguais.
C. Não é suficiente: um losango com ângulos de 60° e 120° tem lados iguais, mas não é regular.
D. É suficiente: quatro lados iguais garantem que os quatro ângulos também sejam iguais.

**Gabarito: C.**

Resolução comentada: A regularidade exige as duas igualdades: de lados e de ângulos. Um losango de ângulos 60°, 120°, 60° e 120° tem os quatro lados iguais, mas não os quatro ângulos iguais; ele seria aprovado pelo teste proposto sem ser regular. É necessário conferir também os ângulos. Um quadrado, por outro lado, atende às duas condições.

- A: O fechamento já faz parte de ser polígono e não garante ângulos iguais.
- B: O quadrado é um quadrilátero com lados e ângulos iguais.
- D: Transforma uma condição necessária em garantia de outra que não decorre dela.

Justificativa da contextualização: A avaliação de um procedimento de qualidade exige justificar por que uma única condição não garante a regularidade.

