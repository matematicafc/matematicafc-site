> Registro da reconstrução inicial. A ressalva da justificativa D de AP-12 foi posteriormente corrigida por autorização do usuário; consulte `ajuste-ap12/relatorio-ajuste.md`. As descrições de fidelidade literal e de pendência dessa justificativa abaixo retratam a versão anterior ao ajuste.

# Reconstrução do Assunto 3 — Ângulos e Polígonos

Data: 17/10/2026. Estado: reconstrução concluída, aguardando avaliação pedagógica e visual do usuário.

## Escopo e fonte

Trabalho exclusivamente em `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/`. O repositório recuperado não foi editado. Fonte recebida: “Texto colado.txt”, documento integral em texto simples, não um Markdown com SVGs incorporados. Cópia individual inalterada arquivada em `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/docs/fontes/angulos-poligonos-revisado-original.txt`.

SHA-256 da fonte: `dbe271c5bca9f9e411993db7bbd1d5cc8a0cc30790c9edb90b43d08315557d26`.

## Entrega

- 25 questões AP-01 a AP-25; 8 fáceis (01–08), 12 médias (09–20), 5 difíceis (21–25).
- 100 alternativas; os 25 gabaritos são coerentes com os modelos matemáticos e conceituais, com uma alternativa correta por questão.
- 21 SVGs: AP-01 a AP-06, AP-09 a AP-18 e AP-21 a AP-25. AP-07, AP-08, AP-19 e AP-20 não tinham descrição visual na fonte; mantidas sem ilustração.
- Todas as descrições acessíveis preservadas literalmente e presentes tanto no metadado quanto no `aria-label`/`title` do SVG.
- Nenhuma questão ativada: `sorteio.ativo: false` e `revisao_pedagogica.status: pendente` nas 25 questões; estado do banco pendente.

## Arquivos principais (caminhos completos)

- Banco: `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/banco-inedito/angulos-poligonos.json`
- Caderno Markdown: `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/docs/revisao-pedagogica/angulos-poligonos.md`
- Caderno HTML: `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/docs/reconstrucao-ap/angulos-poligonos.html`
- SVGs: `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/recursos-visuais/AP-XX.svg` (21 arquivos, identificados no inventário completo).
- Auditoria individual: `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/docs/reconstrucao-ap/auditoria-individual.md`
- Este relatório: `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/docs/reconstrucao-ap/relatorio-reconstrucao.md`
- Inventário de arquivos e hashes: `/workspace/matematicafc-recuperacao-a44c8e4-7fw62a0x/desenvolvimento-bloco3/6-ano/bloco-3/docs/reconstrucao-ap/manifesto-arquivos.json`

A lista exaustiva de arquivos da área está no manifesto; inclui fonte, banco, cadernos, estilos, scripts locais de revisão, testes, capturas e resultados. Os arquivos de GU e PA existentes foram preservados. Os índices gerais foram atualizados para indicar a disponibilidade de AP; os relatórios iniciais continuam arquivados como históricos.

## Fidelidade e diferenças

Nenhum enunciado, título, alternativa, gabarito, resolução, objetivo (habilidade), justificativa de distrator ou descrição acessível foi reescrito. A comparação de todos esses campos com o texto recebido passou. A justificativa da contextualização foi preservada no campo `justificativa_pedagogica`.

Diferenças técnicas de representação:

1. Alternativas numeradas 1–4 na fonte passaram às letras A–D, na mesma ordem, compatíveis com os gabaritos A–D fornecidos. O texto de cada alternativa é idêntico ao original.
2. Foram adicionados IDs exclusivos `MFC6-B3-I-AP-01` a `MFC6-B3-I-AP-25`, metadados de proveniência, grupos de equivalência exclusivos e flags de revisão/sorteio. Esses metadados não constavam da fonte. Nenhum código BNCC ou tópico curricular numérico foi inventado.
3. Os SVGs são reconstruções novas das descrições. Não foi possível comparar com ilustrações originais, pois o arquivo recebido contém descrições, não os SVGs anteriores.
4. Nos esquemas sem medida indicada, foram escolhidas coordenadas apenas para satisfazer a descrição: AP-01, direções 0°/50°; AP-02, aberturas 90°/45°/120°/180°; AP-03, aberturas 45°/120°. Esses números ficam somente nos dados de construção, não como medidas adicionais no enunciado ou rótulos da questão. Os contornos sem medidas têm coordenadas esquemáticas, sem unidade inventada.
5. Comparações de figuras usam a mesma unidade de construção em cada SVG. Medidas repetidas foram organizadas em legendas por peça, com marcas iguais nos lados, sem rótulos de resposta correta ou aprovação. AP-25 mantém as duas peças com o mesmo tratamento visual.
6. Nos transferidores, todas as marcas de 10° estão presentes; a numeração é espaçada entre as duas escalas para evitar sobreposição. Pequenos fundos brancos preservam a leitura onde o raio cruza um número. Nenhuma alteração de posição angular foi feita.

## Conferências especiais

- AP-09: raios a 0° e 70°, com zero inicial à direita. Leitura correta 70° (C).
- AP-10: raios a 180° e 140° na referência direita; abertura 40°, com zero inicial à esquerda. Leitura correta 40° (C).
- AP-22: raios a 20° e 130° da mesma escala; abertura 110° (D).
- AP-23: preservada a versão acessível da câmera, sem “rotação líquida” no enunciado; giro adicional 200° (B). O SVG ilustra somente os três comandos, não a orientação final nem a resposta.
- AP-25: quadrado e losango não quadrado, ambos com lados de 2 cm; o segundo tem ângulos 60°/120°. Gabarito C preservado.

## Testes automatizados executados

- **16 testes Python aprovados**: totais, dificuldades, IDs, 100 alternativas, igualdade dos campos com a fonte, candidato correto único derivado de modelos, bloqueio do sorteio, XML, descrição acessível, contornos, escalas, triângulos proporcionais, comparações em mesma escala, câmera, quadrado/losango, preservação de 89 arquivos, fonte inalterada e cópias de referência idênticas. Há verificações por subcaso nas 25 questões.
- **4 cenários Node aprovados** com os componentes originais recuperados, importados sem alterações: todas corretas (25/0/0), mista (10/10/5), todas em branco (0/0/25) e rejeição do banco AP isolado pelo carregador específico do Bloco 2. Conferidos IDs após embaralhamento, gabaritos, resoluções, resultados e boletim, bem como bloqueio de correção antes do encerramento e de respostas após encerrar.
- **Renderização no Chromium em 320 e 1.280 px**: em cada largura, 25 questões, 100 alternativas e 21 SVGs carregados pelo renderizador seguro original. Nenhum erro JavaScript, recurso HTTP ausente, requisição externa, transbordamento horizontal, caixa de texto fora do SVG ou sobreposição detectada entre textos.
- Fonte mínima efetivamente renderizada nos SVGs: cerca de 12.36 px em 320 px e 17.78 px em 1.280 px.
- **Compatibilidade de impressão/PDF**: o boletim isolado de teste com 25 questões foi processado pelos módulos originais do Bloco 2. Documento de impressão com 25 questões, 21 SVGs e 25 resoluções. PDF gerado com 24 páginas, questões 1–25 identificadas por extração de texto e nenhum aviso de conversão das imagens. Não foi construída uma aplicação estudantil nem realizada seleção de 30 questões neste banco isolado.

Resultados: `testes-estrutura-matematica.log`, `testes-componentes.json`, `testes-renderizacao.json` e respectivos roteiros em `testes/`.

## Inspeção visual realizada

As capturas dos 21 SVGs em ambas as larguras foram examinadas, incluindo as folhas de contato. Conferidos contornos, orientação das escalas, posições dos raios, unidades, proporções dos triângulos e quadriláteros, hachura da face frontal, sinais e legendas. Os gráficos essenciais usam traço escuro sobre branco, com contraste calculado de 11.48:1, além de tracejados, hachuras e marcas, sem depender apenas de cores.

Na primeira renderização foram detectadas colisões de números nas duas escalas e proximidade entre “Sul” e “Início: leste”. Corrigidas apenas no desenho, com nova renderização final sem colisões. Na revisão visual, o contorno D de AP-04 foi ajustado para ter exatamente três trechos retos e um curvo, como a fonte descreve.

## Ressalva da fonte, mantida para avaliação

**AP-12, justificativa do distrator D (20°):** a fonte diz “Completa um ângulo reto, apesar de a referência ser uma linha reta.” Como a abertura informada é 110°, não há complemento positivo até 90°. O erro plausível de obter 20° pode ser explicado como tomar a diferença entre 110° e 90°, confundindo a referência; essa redação alternativa NÃO foi aplicada. O gabarito B (70°) e a resolução 180° − 110° = 70° estão corretos. A ressalva limita-se à explicação do distrator, não às alternativas ou ao resultado.

## Limites e pendências

- Aguardam-se a aprovação humana das novas ilustrações e a decisão sobre a justificativa de AP-12. Nenhuma aprovação automática foi registrada.
- Não houve teste humano em leitor de tela, telefone físico ou impressão em papel. A inspeção em 320/1.280 px é técnica em navegador emulado.
- A estrutura de dados e os componentes de correção/resultados/boletim/recursos/PDF/impressão mostraram compatibilidade. O mecanismo completo do Bloco 3 ainda exige configuração própria e os outros bancos. O carregador publicado do Bloco 2 exige quatro assuntos e IDs do Bloco 2; não foi alterado para aceitar AP nem se declarou que um banco isolado já é um simulado completo.
- Os campos `dados`/modelos adicionais são metadados técnicos de teste e não substituem o conteúdo pedagógico. A validação conceitual depende também dos predicados explícitos no roteiro e da leitura individual documentada, não de uma suposta interpretação automática irrestrita de linguagem natural.
- Não houve nova verificação pelo Microsoft Defender, nem declaração de ausência de ameaças.
- Nenhum teste de sorteio de 30 questões foi simulado com questões inventadas ou bancos provisórios.

## Preservação

Os 89 arquivos recuperados continuam com os hashes originais, e o Git dessa cópia permanece limpo. Nenhuma questão de GU/PA foi criada ou alterada; Assunto 4 não iniciado. Não houve commit, push, merge, deploy, ZIP ou alterações no Blogger.

## Como repetir a inspeção neste ambiente

Na pasta independente do Bloco 3: `python3 testes/testar-reconstrucao-ap.py` e `node testes/testar-componentes.mjs`. Para o teste de navegador, iniciar um servidor somente local na raiz da recuperação com `python3 -m http.server 8773 --bind 127.0.0.1`, e executar `python3 testes/testar-renderizacao-ap.py` a partir do Bloco 3. O caderno usa `fetch` local, portanto precisa de HTTP para abrir; o arquivo HTML sozinho por `file://` não carrega o JSON. O servidor de teste foi encerrado após a verificação. Nenhum endereço localhost deste ambiente foi oferecido como acesso pelo notebook e nenhuma transferência/distribuição foi preparada.
