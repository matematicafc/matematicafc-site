# Conferência individual — AP-01 a AP-25

As respostas abaixo foram conferidas com os enunciados originais e com modelos conceituais, aritméticos e geométricos. A aprovação pedagógica permanece pendente.

| Questão | Nível | Gabarito | Conferência |
|---|---|---|---|
| AP-01 | facil | A | O é a origem comum das semirretas OA e OB. |
| AP-02 | facil | D | As direções 45° e 135° de A diferem 90°; os demais desenhos têm aberturas 45°, 120° e 180°. Esses números são geometria de construção, não medidas acrescentadas ao enunciado. |
| AP-03 | facil | A | O esquema A é agudo e o B é obtuso; aumentar o comprimento não aumenta a abertura. |
| AP-04 | facil | B | A é fechado e retilíneo; B é aberto; C é curvo; D tem três trechos retos e um curvo. |
| AP-05 | facil | D | Um percurso fechado pelos seis vértices distintos tem seis lados e seis vértices. |
| AP-06 | facil | B | 5 + 5 > 8; dois lados de 5 cm e um de 8 cm formam um triângulo isósceles. Coordenadas (0,0), (8,0), (4,3) confirmam as medidas. |
| AP-07 | facil | D | Quatro ângulos retos garantem retângulo; um retângulo 4 × 2 é contraexemplo à exigência de quadrado. Um quadrado também satisfaz a definição de retângulo. |
| AP-08 | facil | A | Direção oposta: 360° / 2 = 180°. |
| AP-09 | media | C | Zero à direita e segundo raio a 70°: abertura 70°. A escala oposta indica 110°. |
| AP-10 | media | C | Zero à esquerda, posição absoluta do outro raio 140° a partir da direita: 180° − 140° = 40°. |
| AP-11 | media | C | 90° − 35° = 55°; conferência 35° + 55° = 90°. |
| AP-12 | media | B | 180° − 110° = 70°; conferência 110° + 70° = 180°. Ressalva editorial na justificativa de D, preservada. |
| AP-13 | media | A | Leste → direita 90° → sul; sul → esquerda 180° → norte, sem deslocamento. |
| AP-14 | media | B | Somente o quadrado C apresenta todos os lados e ângulos iguais. Os outros modelos falham em pelo menos uma condição. |
| AP-15 | media | C | Triângulo com lados 3, 4 e 5: três lados distintos, portanto escaleno; 3² + 4² = 5² confirma a geometria construída com ângulo reto. Essa identidade não foi acrescentada à resolução do estudante. |
| AP-16 | media | B | Quadrado de lado 3 cm: atende simultaneamente a quatro lados iguais e quatro ângulos retos; etiquetas losango e retângulo. |
| AP-17 | media | C | 90° + 120° + 80° = 290°; 360° − 290° = 70°. |
| AP-18 | media | A | A face frontal tem cinco lados, independentemente das arestas desenhadas para a profundidade. |
| AP-19 | media | D | Quatro lados iguais em quadrilátero convexo garantem losango, mas não ângulos retos. |
| AP-20 | media | A | Direções mantidas com articulação travada preservam 60°; comprimentos não alteram a medida angular. |
| AP-21 | dificil | C | O modelo A tem lados de 2 cm, dois pares de lados opostos paralelos e ângulos 60°/120°. B e C têm ângulos retos; D tem apenas um par de lados paralelos. |
| AP-22 | dificil | D | 130° − 20° = 110°. Os raios foram verificados pelas coordenadas efetivamente desenhadas. |
| AP-23 | dificil | B | 80° + 110° = 190°; 190° − 30° = 160°; 360° − 160° = 200°. A ordem e os sentidos originais estão preservados. |
| AP-24 | dificil | D | Todo quadrado é retângulo; o retângulo A de lados 4 cm e 2 cm não é quadrado e refuta a recíproca. |
| AP-25 | dificil | C | A tem lados de 2 cm e quatro ângulos retos; B tem lados de 2 cm e ângulos 60°/120°, portanto não é regular. Igualdade dos lados não garante regularidade. |
