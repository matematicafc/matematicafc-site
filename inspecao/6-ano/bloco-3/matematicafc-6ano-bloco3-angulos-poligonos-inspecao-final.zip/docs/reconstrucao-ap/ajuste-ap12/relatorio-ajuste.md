# Ajuste final — AP-12

Data: 17/10/2026. Realizado exclusivamente na área independente do Bloco 3. A aprovação pedagógica final continua pendente.

## Análise da questão completa

O enunciado estabelece uma borda reta dividida em duas aberturas, 110° e uma desconhecida. O SVG mostra semirretas nas direções 0°, 110° e 180°, e a marca de interrogação entre as duas últimas. As alternativas são A: 290°, B: 70°, C: 110°, D: 20°. A abertura correta é 180° − 110° = 70°, confirmada por 110° + 70° = 180°. O gabarito B e a resolução foram preservados.

## Justificativa anterior do distrator D

> Completa um ângulo reto, apesar de a referência ser uma linha reta.

Essa explicação é inadequada: 110° já supera 90°, então não existe uma abertura positiva que, somada a 110°, complete um ângulo reto. Fazer 90° − 110° resultaria em −20°, não nos 20° da alternativa. O erro plausível é calcular o excesso de 110° sobre 90°, confundindo a referência, quando se deve encontrar o que falta até 180°.

## Nova justificativa

> Calcula 110° − 90° = 20°, comparando com um ângulo reto, em vez de calcular quanto falta para completar a meia volta de 180°.

## Escopo das alterações

- No JSON, alterados somente `questoes[11].justificativas_distratores.D` e a cópia da mesma explicação em `questoes[11].alternativas[3].erro_comum`.
- Caderno Markdown atualizado com essa mesma justificativa. O HTML lê o JSON e passou a exibi-la sem alteração de seu código.
- Fonte original arquivada permaneceu inalterada; o desvio autorizado está documentado em `../ajustes-editoriais.json`. O gerador e o teste de fidelidade foram ajustados para aplicar/verificar somente essa exceção.
- O relatório inicial recebeu uma nota histórica apontando para este ajuste. Nenhuma mudança nos dados das outras 24 questões, nas alternativas, enunciado, habilidade, nível, gabarito, resolução, SVG ou descrição acessível da AP-12.

## Resultados dos testes executados

- **7 testes específicos aprovados:** diferença limitada à justificativa D; hashes dos dados das outras 24 questões; SVG e medidas 0°/110°/180°; alternativa correta única de 70°; explicação do cálculo incorreto 110° − 90° = 20°; fonte original, Markdown e bloqueio do sorteio preservados; sintaxe do gerador/testes; renderização em 320 e 1.280 px.
- **16 testes de regressão estrutural/matemática aprovados**, incluindo as 25 questões, 100 alternativas, dificuldades, fonte com a única exceção autorizada, modelos de gabaritos e preservação dos 89 arquivos recuperados.
- No navegador, a AP-12 exibiu a nova justificativa, as quatro alternativas e o SVG, sem erros JavaScript ou transbordamento horizontal nas duas larguras. Capturas em `AP-12-320.png` e `AP-12-1280.png`.
- A comparação integral da AP-12 com o registro anterior confirmou que apenas as duas representações da mesma justificativa foram alteradas. O arquivo externo do SVG e os dados das outras 24 questões conservaram seus hashes.

Evidências: `testes-ap12.log`, `regressao-estrutura.log`, `renderizacao.json` e `estado-anterior.json`, nesta pasta.

## Estado final

AP-12 continua média, gabarito B (70°), revisão pendente e sorteio inativo. As 25 questões permanecem desativadas. Não houve commit, push, merge, deploy, alteração no Blogger ou nos simulados publicados. Aguardamos aprovação final.
